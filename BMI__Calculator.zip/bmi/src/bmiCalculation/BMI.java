package bmiCalculation;

public class BMI {
	
	public static double calculateBMIinkg(double weight,double height){
		double result=(weight /(Math.pow(height, 2)));
		return result;
		
	}public static double calMinWeightInMeter(double height){
		double heightInInch=height/0.0254;
		double iwb=calculateMinWeightInInch(heightInInch);
		double result=iwb*0.45;
		return result;
		
	}
	public static double calMaxWeightInMeter(double height){
		double heightInInch=height/0.0254;
		double iwb=calculateMaxWeightInInch(heightInInch);
		double result=iwb*0.45;
		return result;
	}
	public static double calWomenNormalWeightInMeter(double height){
		double counterbalance=((height*100)-100);
		double fifteenPerOfWeight=counterbalance*15/100;
		double normal=counterbalance-fifteenPerOfWeight;
		return normal;
		
	}
	public static double calMenNormalWeightInMeter(double height){
		double counterbalance=((height*100)-100);
		double tenthPerOfWeight=counterbalance*10/100;
		double normal=counterbalance-tenthPerOfWeight;
		return normal;
	}
	public static double calculateBMIinpound(double weight,double hieght){
		double result=(weight*703/Math.pow(hieght, 2));
		return result;
	}
	public static double calculateMinWeightInInch(double height){
		double result=(((Math.pow(height, 2)*18.5)/705));
		return result;
		
	}
	public static double calculateMaxWeightInInch(double height){
		double result=(((Math.pow(height, 2)*24)/705));
		return result;
	}
	
	public static double calWomenNormalWeightInInch(double height){
		double height2=height*0.0254;
		double normal=calWomenNormalWeightInMeter(height2);
		double  normal2= (normal*2.2046);
		return normal2;
		
	}
	public static double calMenNormalWeightInInch(double height){
	double height2=height*0.0254;
	double normal=calMenNormalWeightInMeter(height2);
	double normal2= (normal*2.2046);
	return normal2;
	}
}
