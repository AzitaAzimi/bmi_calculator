package bmiCalculation;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class BMI_Application extends JFrame implements ActionListener {

	private JLabel lblWeight, lblHeight, lblGender, lblAge, lblleaf1,
			lblleaf2, lblBMIgif, lblBMI, lblBMIChart, lblText, lblNormal,
			lblMin, lblMax, lblLine1, lblline2,lblimage5;
	private JButton btnCalculate, btnReset;
	private JTextField txtWeight, txtHeight, txtAge, txtBMI, txtNormal, txtMin,
			txtMax;
	private JPanel jp1, jp2, jp3;
	private ImageIcon image1, image2, image3, image4, image6, image5,text;
	private JComboBox cmbWeight, cmbGender, cmbHeight;

	public BMI_Application() {
		JTabbedPane jtp1 = new JTabbedPane();
		setSize(750, 600);
		jp1 = new JPanel();
		jp2 = new JPanel();
		jp3 = new JPanel();
		jp1.setLayout(null);
		jp2.setLayout(null);
		jp3.setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		image1 = new ImageIcon(getClass().getResource("leaf1.png"));
		lblleaf1 = new JLabel(image1);
		lblleaf1.setBounds(270, 0, 376, 70);

		image2 = new ImageIcon(getClass().getResource("leaf.png"));
		lblleaf2 = new JLabel(image2);
		lblleaf2.setBounds(645, 0, 80, 370);
		image3 = new ImageIcon(getClass().getResource("BMI.gif"));
		lblBMIgif = new JLabel(image3);
		lblBMIgif.setBounds(0, 65, 700, 168);

		jp1.add(lblleaf2);
		jp1.add(lblBMIgif);
		jp1.add(lblleaf1);

		lblWeight = new JLabel("Weight");
		lblWeight.setBounds(30, 235, 70, 40);
		lblWeight.setForeground(Color.YELLOW);
		lblWeight.setFont(new Font("Freestyle Script", 0, 30));
		jp1.add(lblWeight);

		txtWeight = new JTextField();
		txtWeight.setBounds(110, 245, 70, 25);
		txtWeight.setForeground(new Color(0, 128, 0));
		txtWeight.setFont(new Font("Arial", Font.BOLD, 15));
		jp1.add(txtWeight);

		String weight[] = { "Kilogram", "Pounds" };
		cmbWeight = new JComboBox(weight);
		cmbWeight.setBackground(Color.WHITE);
		cmbWeight.setBounds(190, 245, 85, 25);
		jp1.add(cmbWeight);

		lblHeight = new JLabel("Height");
		lblHeight.setBounds(370, 235, 70, 40);
		lblHeight.setForeground(Color.YELLOW);
		lblHeight.setFont(new Font("Freestyle Script", 0, 30));
		jp1.add(lblHeight);

		txtHeight = new JTextField();
		txtHeight.setBounds(450, 245, 70, 25);
		txtHeight.setForeground(new Color(0, 128, 0));
		txtHeight.setFont(new Font("Arial", Font.BOLD, 15));
		jp1.add(txtHeight);

		String height[] = { "Meters", "Inches" };
		cmbHeight = new JComboBox(height);
		cmbHeight.setBackground(Color.WHITE);
		cmbHeight.setBounds(530, 245, 85, 25);
		jp1.add(cmbHeight);

		lblAge = new JLabel("Age");
		lblAge.setBounds(100, 290, 70, 40);
		lblAge.setForeground(Color.YELLOW);
		lblAge.setFont(new Font("Freestyle Script", 0, 30));
		jp1.add(lblAge);

		txtAge = new JTextField();
		txtAge.setBounds(150, 295, 70, 25);
		txtAge.setForeground(new Color(0, 128, 0));
		txtAge.setFont(new Font("Arial", Font.BOLD, 15));
		jp1.add(txtAge);

		lblGender = new JLabel("Gender");
		lblGender.setBounds(440, 290, 70, 40);
		lblGender.setForeground(Color.YELLOW);
		lblGender.setFont(new Font("Freestyle Script", 0, 30));
		jp1.add(lblGender);

		String gender[] = { "Male", "Female" };
		cmbGender = new JComboBox(gender);
		cmbGender.setBounds(500, 295, 70, 25);
		cmbGender.setBackground(Color.WHITE);
		jp1.add(cmbGender);

		lblLine1 = new JLabel(
				"___________________________________________________________________________");
		lblLine1.setForeground(Color.YELLOW);
		lblLine1.setBounds(50, 335, 550, 20);
		jp1.add(lblLine1);

		lblBMI = new JLabel("BMI");
		lblBMI.setBounds(150, 360, 50, 40);
		lblBMI.setForeground(Color.YELLOW);
		lblBMI.setFont(new Font("Monotype Corsiva", 0, 25));
		jp1.add(lblBMI);

		txtBMI = new JTextField();
		txtBMI.setForeground(new Color(0, 128, 0));
		txtBMI.setFont(new Font("Arial", Font.BOLD, 15));
		txtBMI.setBounds(200, 365, 90, 25);
		jp1.add(txtBMI);

		lblNormal = new JLabel("Normal Weight");
		lblNormal.setForeground(Color.YELLOW);
		lblNormal.setFont(new Font("Monotype Corsiva", 0, 20));
		lblNormal.setBounds(360, 360, 150, 35);
		jp1.add(lblNormal);

		txtNormal = new JTextField();
		txtNormal.setForeground(new Color(0, 128, 0));
		txtNormal.setFont(new Font("Arial", Font.BOLD, 15));
		txtNormal.setBounds(480, 365, 90, 25);
		jp1.add(txtNormal);

		lblMin = new JLabel("Minimum Weight");
		lblMin.setForeground(Color.YELLOW);
		lblMin.setFont(new Font("Monotype Corsiva", 0, 20));
		lblMin.setBounds(70, 400, 150, 40);
		jp1.add(lblMin);

		txtMin = new JTextField();
		txtMin.setForeground(new Color(0, 128, 0));
		txtMin.setFont(new Font("Arial", Font.BOLD, 15));
		txtMin.setBounds(200, 400, 90, 25);
		jp1.add(txtMin);

		lblMax = new JLabel("Maximum Weight");
		lblMax.setForeground(Color.YELLOW);
		lblMax.setFont(new Font("Monotype Corsiva", 0, 20));
		lblMax.setBounds(340, 400, 150, 40);
		jp1.add(lblMax);

		txtMax = new JTextField();
		txtMax.setForeground(new Color(0, 128, 0));
		txtMax.setFont(new Font("Arial", Font.BOLD, 15));
		txtMax.setBounds(480, 400, 90, 25);
		jp1.add(txtMax);

		lblline2 = new JLabel(
				"_____________________________________________________________________________________");
		lblline2.setForeground(Color.YELLOW);
		lblline2.setBounds(30, 465, 620, 20);
		jp1.add(lblline2);

		btnCalculate = new JButton("Calculate");
		btnCalculate.setBackground(Color.WHITE);
		btnCalculate.setForeground(new Color(0, 128, 0));
		btnCalculate.setFont(new Font("Arial", Font.BOLD, 15));
		btnCalculate.setBounds(375, 490, 110, 30);
		btnCalculate.setBorder(BorderFactory.createLineBorder(Color.YELLOW));
		btnCalculate.addActionListener(this);
		jp1.add(btnCalculate);

		btnReset = new JButton("Reset");
		btnReset.setBackground(Color.WHITE);
		btnReset.setForeground(new Color(0, 128, 0));
		btnReset.setFont(new Font("Arial", Font.BOLD, 15));
		btnReset.setBounds(250, 490, 110, 30);
		btnReset.setBorder(BorderFactory.createLineBorder(Color.YELLOW));
		btnReset.addActionListener(this);
		jp1.add(btnReset);

		text = new ImageIcon(getClass().getResource("BMI.png"));
		lblText = new JLabel(text);
		lblText.setBounds(70,10, 595,269);
		jp2.add(lblText);
		
		image4 = new ImageIcon(getClass().getResource("BMIchart.png"));
		lblBMIChart = new JLabel(image4);
		lblBMIChart.setBounds(10, 300, 455, 208);
		jp2.add(lblBMIChart);
		
		image5=new ImageIcon(getClass().getResource("Age&BMI.png"));
		lblimage5=new JLabel(image5);
		lblimage5.setBounds(480, 320, 234, 161);
		lblimage5.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		jp2.add(lblimage5);

		image6 = new ImageIcon(getClass().getResource("Capture.png"));
		JLabel lblimage6 = new JLabel(image6);
		lblimage6.setBorder(BorderFactory.createLineBorder(new Color(0,90,0)));
		lblimage6.setBounds(50, 50, 649, 422);
		jp3.add(lblimage6);

		jp1.setBackground(new Color(0, 90, 0));
		jp2.setBackground(new Color(0, 90, 0));
		jp3.setBackground(new Color(0, 90, 0));
		jtp1.addTab("Calculator", jp1);
		jtp1.addTab("BMI", jp2);
		jtp1.addTab("Information", jp3);
		jtp1.setBackground(Color.WHITE);
		jtp1.setBounds(0, 0, 750, 500);
		add(jtp1);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnReset) {
			txtWeight.setText("");
			txtHeight.setText("");
			txtAge.setText("");
			txtBMI.setText("");
			txtNormal.setText("");
			txtMax.setText("");
			txtMin.setText("");
		}
		if (e.getSource() == btnCalculate) {
			if (cmbWeight.getSelectedIndex() == 0
					&& cmbHeight.getSelectedIndex() == 0) {
				String weight = txtWeight.getText();
				double weight2 = Double.parseDouble(weight);
				String height = txtHeight.getText();
				double height2 = Double.parseDouble(height);
				txtBMI.setText(String.format("%.2f",
						BMI.calculateBMIinkg(weight2, height2)));
				txtMax.setText(String.format("%.2f",
						BMI.calMaxWeightInMeter(height2)));
				txtMin.setText(String.format("%.2f",
						BMI.calMinWeightInMeter(height2)));
				if(cmbGender.getSelectedIndex()==0){
					System.out.println(  cmbGender.getSelectedIndex()   );
					System.out.println( cmbGender.getSelectedItem()  );
					double result =  BMI.calMenNormalWeightInMeter(height2);
					txtNormal.setText(String.format("%.2f", result));
				}
				 if (cmbGender.getSelectedIndex()==1){
					 System.out.println(  cmbGender.getSelectedIndex()   );
					 double result =  BMI.calWomenNormalWeightInMeter(height2);
					txtNormal.setText(String.format("%.2f", result));
				}
			}
			} if (cmbWeight.getSelectedIndex() == 1
					&& cmbHeight.getSelectedIndex() == 1) {
				String weight = txtWeight.getText();
				double weight2 = Double.parseDouble(weight);
				String height = txtHeight.getText();
				double height2 = Double.parseDouble(height);
				txtBMI.setText(String.format("%.2f",
						BMI.calculateBMIinpound(weight2, height2)));
				txtMax.setText(String.format("%.2f",
						BMI.calculateMaxWeightInInch(height2)));
				txtMin.setText(String.format("%.2f",
						BMI.calculateMinWeightInInch(height2)));
				if(cmbGender.getSelectedIndex()==0){
					double result1= BMI.calMenNormalWeightInInch(height2);
					txtNormal.setText(String.format("%.2f",result1));					
				}
				if (cmbGender.getSelectedIndex()==1){
					double result1= BMI.calWomenNormalWeightInInch(height2);
					txtNormal.setText(String.format("%.2f",result1));
			    }
		}

	} 
}

