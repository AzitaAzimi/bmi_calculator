package bmiCalculation;
import javax.swing.*;

public class BMI_Interface {

	BMI_Interface() {

		JWindow window1 = new JWindow();
		window1.getContentPane().add(

		new JLabel(new ImageIcon(getClass().getResource("Image.gif"))));
		window1.setBounds(400, 130, 500, 400);
		window1.setVisible(true);
		try {
			Thread.sleep(3000);
			window1.setVisible(false);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] arg) {
		new BMI_Interface();
	new BMI_Application();
	new BMI();
	}

}
